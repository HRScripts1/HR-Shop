# HR Shop (Paper 26.2)

A configurable Minecraft GUI shop plugin for Paper 26.2.

## Requirements
- Paper 26.2
- Java 25
- Vault
- An economy provider such as EssentialsX Economy

## Build
Install JDK 25 and Maven, then run in this folder:
```bash
mvn clean package
```
The output JAR will be `target/hr-shop-1.0.0.jar`.

## Install
1. Install Vault and an economy plugin on the Paper server.
2. Stop the server.
3. Put `hr-shop-1.0.0.jar` in the server's `plugins` folder.
4. Start the server. HR Shop creates `plugins/HRShop/config.yml`.
5. Edit prices/categories in `config.yml`, then run `/hrshop reload`.

## Commands
- `/shop` - Open the shop.
- `/hrshop` or `/hrshop edit` - Open admin GUI (OP or `hrshop.admin`).
- `/hrshop reload` - Reload config (OP or `hrshop.reload`).

## Admin GUI workflow
- Add Section: type a section name in chat.
- Delete Section: select a section.
- Add Item (Main Hand): hold an item, select a section, then enter `BUY SELL` in chat.
- Delete Item: select section, then item.
- Edit Item Prices: select section, then item, then enter `BUY SELL` in chat.

Prices are per item. A sell price of `0` disables selling. Players click an item to buy 1; shift-click buys 16. In a section, the Sell Hand button sells the full main-hand stack when that item has a configured sell price.

## Notes
- Vault and an economy provider are required for transactions.
- This is a source project; the JAR must be built with Maven. It has not been compiled or tested against a live Paper server in this environment.
- Paper 26.2 API documentation: https://jd.papermc.io/paper/26.2/
