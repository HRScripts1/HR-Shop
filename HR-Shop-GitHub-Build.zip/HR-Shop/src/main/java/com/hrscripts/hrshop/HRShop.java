package com.hrscripts.hrshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class HRShop extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private Economy economy;
    private final Map<UUID, PendingInput> pending = new HashMap<>();
    private final Map<UUID, String> selectedSection = new HashMap<>();
    private enum Menu { MAIN, SECTION, ADMIN, DELETE_SECTION, PICK_DELETE_ITEM_SECTION, PICK_EDIT_ITEM_SECTION, DELETE_ITEM, EDIT_ITEM }
    private record PendingInput(String action, String section, Material material) {}

    @Override public void onEnable() {
        saveDefaultConfig();
        setupEconomy();
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("shop")).setExecutor(this);
        Objects.requireNonNull(getCommand("hrshop")).setExecutor(this);
        Objects.requireNonNull(getCommand("hrshop")).setTabCompleter(this);
        getLogger().info("HR Shop enabled. Economy: " + (economy != null));
    }
    private void setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) economy = rsp.getProvider();
    }
    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
    private String msg(String key) { return color(getConfig().getString("messages."+key, "&c"+key)); }
    private String money(double n) { return getConfig().getString("settings.currency-symbol", "$") + String.format(Locale.US, "%.2f", n); }
    private ItemStack icon(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) { meta.setDisplayName(color(name)); meta.setLore(lore.stream().map(this::color).toList()); item.setItemMeta(meta); }
        return item;
    }
    private Inventory menu(Menu type, String section, String title, int size) {
        return Bukkit.createInventory(new ShopHolder(type, section), size, color(title));
    }
    private void filler(Inventory inv) {
        ItemStack pane = icon(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i=0;i<inv.getSize();i++) if (inv.getItem(i)==null) inv.setItem(i,pane);
    }
    private List<String> sections() {
        ConfigurationSection sec = getConfig().getConfigurationSection("sections");
        return sec == null ? new ArrayList<>() : new ArrayList<>(sec.getKeys(false));
    }
    private void openMain(Player p) {
        List<String> names = sections();
        Inventory inv = menu(Menu.MAIN, null, getConfig().getString("settings.shop-title","&8HR Shop"), 54);
        int slot=10;
        for (String name : names) {
            Material mat = Material.matchMaterial(getConfig().getString("sections."+name+".icon","CHEST"));
            if (mat == null || !mat.isItem()) mat=Material.CHEST;
            inv.setItem(slot, icon(mat, "&b"+name, List.of("&7Click to browse", "&eOpen section")));
            slot++; if (slot==17) slot=19; if (slot==26) slot=28; if (slot>=44) break;
        }
        inv.setItem(49, icon(Material.BARRIER,"&cClose",List.of("&7Close the shop")));
        filler(inv); p.openInventory(inv);
    }
    private void openSection(Player p, String section) {
        ConfigurationSection items = getConfig().getConfigurationSection("sections."+section+".items");
        if (items == null) { p.sendMessage(color("&cThis section is empty.")); return; }
        Inventory inv = menu(Menu.SECTION, section, "&8Shop: &b"+section, 54);
        int slot=0;
        for (String key : items.getKeys(false)) {
            Material mat=Material.matchMaterial(key);
            if (mat==null || !mat.isItem()) continue;
            double buy=items.getDouble(key+".buy",0), sell=items.getDouble(key+".sell",0);
            inv.setItem(slot++, icon(mat, "&f"+pretty(key), List.of("&7Buy: &a"+money(buy), "&7Sell: &c"+money(sell), "&eLeft-click to buy 1", "&eShift-click to buy 16")));
            if (slot>=45) break;
        }
        inv.setItem(45, icon(Material.ARROW,"&eBack",List.of("&7Back to categories")));
        inv.setItem(49, icon(Material.HOPPER,"&aSell Hand",List.of("&7Sell the item in your main hand")));
        inv.setItem(53, icon(Material.BARRIER,"&cClose",List.of()));
        filler(inv); p.openInventory(inv);
    }
    private String pretty(String key) { return Arrays.stream(key.toLowerCase(Locale.ROOT).split("_")).map(s->s.isEmpty()?s:Character.toUpperCase(s.charAt(0))+s.substring(1)).reduce((a,b)->a+" "+b).orElse(key); }
    private void openAdmin(Player p) {
        Inventory inv=menu(Menu.ADMIN,null,getConfig().getString("settings.admin-title","&8HR Shop &cAdmin"),27);
        inv.setItem(10,icon(Material.EMERALD,"&aAdd Section",List.of("&7Create a new shop section")));
        inv.setItem(11,icon(Material.BARRIER,"&cDelete Section",List.of("&7Choose a section to delete")));
        inv.setItem(12,icon(Material.CHEST,"&bAdd Item (Main Hand)",List.of("&7Hold the item you want to add", "&7Then select a section")));
        inv.setItem(13,icon(Material.HOPPER,"&eDelete Item",List.of("&7Choose a section and item")));
        inv.setItem(14,icon(Material.ANVIL,"&dEdit Item Prices",List.of("&7Choose an item to edit prices")));
        inv.setItem(15,icon(Material.PAPER,"&eReload Config",List.of("&7Reload config.yml")));
        inv.setItem(22,icon(Material.BARRIER,"&cClose",List.of()));
        filler(inv); p.openInventory(inv);
    }
    private void openSectionPicker(Player p, Menu type, String title) {
        Inventory inv=menu(type,null,title,54); int slot=0;
        for(String s:sections()) {
            Material m=Material.matchMaterial(getConfig().getString("sections."+s+".icon","CHEST")); if(m==null||!m.isItem())m=Material.CHEST;
            inv.setItem(slot++,icon(m,"&b"+s,List.of("&7Click to select")));
            if(slot>=45)break;
        }
        inv.setItem(49,icon(Material.ARROW,"&eBack",List.of())); filler(inv); p.openInventory(inv);
    }
    private void openItemAdmin(Player p, String section, Menu type) {
        ConfigurationSection items=getConfig().getConfigurationSection("sections."+section+".items");
        Inventory inv=menu(type,section,"&8"+(type==Menu.DELETE_ITEM?"Delete: ":"Edit prices: ")+section,54);
        int slot=0;
        if(items!=null) for(String key:items.getKeys(false)) {
            Material m=Material.matchMaterial(key); if(m==null||!m.isItem())continue;
            inv.setItem(slot++,icon(m,"&f"+pretty(key),List.of("&7Buy: &a"+money(items.getDouble(key+".buy")), "&7Sell: &c"+money(items.getDouble(key+".sell")), "&eClick to select")));
            if(slot>=45)break;
        }
        inv.setItem(49,icon(Material.ARROW,"&eBack",List.of())); filler(inv); p.openInventory(inv);
    }
    private boolean isAdmin(Player p) { return p.isOp() || p.hasPermission("hrshop.admin"); }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(command.getName().equalsIgnoreCase("shop")) {
            if(!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
            if(!p.hasPermission("hrshop.use")) { p.sendMessage(msg("no-permission")); return true; }
            openMain(p); return true;
        }
        if(!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        if(!isAdmin(p)) { p.sendMessage(msg("no-permission")); return true; }
        if(args.length>0 && args[0].equalsIgnoreCase("reload")) {
            if(!p.hasPermission("hrshop.reload") && !p.isOp()) { p.sendMessage(msg("no-permission")); return true; }
            reloadConfig(); setupEconomy(); p.sendMessage(color("&aHR Shop configuration reloaded.")); return true;
        }
        if(args.length==0 || args[0].equalsIgnoreCase("edit")) { openAdmin(p); return true; }
        p.sendMessage(color("&e/hrshop edit &7- Open admin GUI"));
        p.sendMessage(color("&e/hrshop reload &7- Reload configuration"));
        return true;
    }
    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if(c.getName().equalsIgnoreCase("hrshop") && args.length==1) return List.of("edit","reload");
        return List.of();
    }
    @EventHandler public void onClick(InventoryClickEvent e) {
        if(!(e.getWhoClicked() instanceof Player p))return;
        if(!(e.getView().getTopInventory().getHolder() instanceof ShopHolder holder))return;
        e.setCancelled(true);
        if(e.getClickedInventory()==null || e.getClickedInventory()!=e.getView().getTopInventory())return;
        int slot=e.getRawSlot(); ItemStack clicked=e.getCurrentItem(); if(clicked==null || clicked.getType()==Material.GRAY_STAINED_GLASS_PANE)return;
        if(holder.type==Menu.SECTION && selectedSection.containsKey(p.getUniqueId())
                && selectedSection.get(p.getUniqueId()).startsWith("ADD:")) {
            String material=selectedSection.get(p.getUniqueId()).substring(4);
            selectedSection.remove(p.getUniqueId());
            String sectionName=ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
            ask(p,new PendingInput("add_item",sectionName,Material.matchMaterial(material)),
                    "Type buying and selling prices: BUY SELL (example: 100 35).");
            return;
        }
        switch(holder.type) {
            case MAIN -> {
                if(slot==49)return;
                String name=ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
                if(sections().contains(name))openSection(p,name);
            }
            case SECTION -> {
                if(slot==45){openMain(p);return;}
                if(slot==49){sellHand(p,holder.section);return;}
                if(slot>=45)return;
                buy(p,holder.section,clicked.getType(),e.isShiftClick()?16:1);
            }
            case ADMIN -> {
                switch(slot) {
                    case 10 -> ask(p,new PendingInput("add_section",null,null),"Type the new section name in chat.");
                    case 11 -> openSectionPicker(p,Menu.DELETE_SECTION,"&8Delete a section");
                    case 12 -> {
                        ItemStack hand=p.getInventory().getItemInMainHand();
                        if(hand.getType()==Material.AIR){p.sendMessage(color("&cHold the item in your main hand first."));return;}
                        openSectionPicker(p,Menu.SECTION,"&8Choose item section");
                        selectedSection.put(p.getUniqueId(),"ADD:"+hand.getType().name());
                    }
                    case 13 -> openSectionPicker(p,Menu.PICK_DELETE_ITEM_SECTION,"&8Choose section");
                    case 14 -> openSectionPicker(p,Menu.PICK_EDIT_ITEM_SECTION,"&8Choose section");
                    case 15 -> {reloadConfig();p.sendMessage(color("&aConfig reloaded."));openAdmin(p);}
                }
            }
            case DELETE_SECTION -> {
                if(slot==49){openAdmin(p);return;}
                String section=ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
                if(getConfig().contains("sections."+section)){getConfig().set("sections."+section,null);saveConfig();p.sendMessage(color("&aDeleted section &f"+section));openSectionPicker(p,Menu.DELETE_SECTION,"&8Delete a section");}
            }
            case PICK_DELETE_ITEM_SECTION -> {
                if(slot==49){openAdmin(p);return;}
                String section=ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
                openItemAdmin(p,section,Menu.DELETE_ITEM);
            }
            case PICK_EDIT_ITEM_SECTION -> {
                if(slot==49){openAdmin(p);return;}
                String section=ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
                openItemAdmin(p,section,Menu.EDIT_ITEM);
            }
            case DELETE_ITEM -> {
                if(slot==49){openSectionPicker(p,Menu.PICK_DELETE_ITEM_SECTION,"&8Choose section");return;}
                String key=clicked.getType().name(); getConfig().set("sections."+holder.section+".items."+key,null);saveConfig();
                p.sendMessage(color("&aDeleted &f"+key));openItemAdmin(p,holder.section,Menu.DELETE_ITEM);
            }
            case EDIT_ITEM -> {
                if(slot==49){openSectionPicker(p,Menu.PICK_EDIT_ITEM_SECTION,"&8Choose section");return;}
                ask(p,new PendingInput("edit_prices",holder.section,clicked.getType()),"Type two prices in chat: BUY SELL (example: 100 35).");
            }
        }

    }
    @EventHandler public void onDrag(InventoryDragEvent e) {
        if(e.getView().getTopInventory().getHolder() instanceof ShopHolder) e.setCancelled(true);
    }
    private void buy(Player p,String section,Material mat,int amount) {
        if(economy==null){p.sendMessage(msg("no-economy"));return;}
        String path="sections."+section+".items."+mat.name();
        if(!getConfig().contains(path)){return;}
        double price=getConfig().getDouble(path+".buy")*amount;
        if(price<=0){p.sendMessage(color("&cThis item is not for sale."));return;}
        if(!economy.has(p,price)){p.sendMessage(msg("no-money").replace("{amount}",money(price)));return;}
        if(p.getInventory().firstEmpty()==-1 && p.getInventory().getItemInMainHand().getAmount()+amount>p.getInventory().getItemInMainHand().getMaxStackSize()) {p.sendMessage(color("&cYour inventory is full."));return;}
        economy.withdrawPlayer(p,price);
        ItemStack stack=new ItemStack(mat,amount); Map<Integer,ItemStack> overflow=p.getInventory().addItem(stack);
        overflow.values().forEach(item->p.getWorld().dropItemNaturally(p.getLocation(),item));
        p.sendMessage(msg("bought").replace("{amount}",String.valueOf(amount)).replace("{item}",pretty(mat.name())).replace("{price}",money(price)));
    }
    private void sellHand(Player p,String section) {
        if(economy==null){p.sendMessage(msg("no-economy"));return;}
        ItemStack hand=p.getInventory().getItemInMainHand();
        if(hand.getType()==Material.AIR){p.sendMessage(color("&cHold an item to sell."));return;}
        String path="sections."+section+".items."+hand.getType().name();
        if(!getConfig().contains(path) || getConfig().getDouble(path+".sell")<=0){p.sendMessage(msg("no-sell-price"));return;}
        int amount=hand.getAmount(); double total=getConfig().getDouble(path+".sell")*amount;
        p.getInventory().setItemInMainHand(null); economy.depositPlayer(p,total);
        p.sendMessage(msg("sold").replace("{amount}",String.valueOf(amount)).replace("{item}",pretty(hand.getType().name())).replace("{price}",money(total)));
    }
    private void ask(Player p,PendingInput input,String prompt) {
        pending.put(p.getUniqueId(),input); p.closeInventory();
        p.sendMessage(color("&e[HR Shop] &f"+prompt+"&7 Type CANCEL to stop."));
    }
    @EventHandler public void onChat(org.bukkit.event.player.AsyncPlayerChatEvent e) {
        PendingInput input=pending.remove(e.getPlayer().getUniqueId()); if(input==null)return;
        e.setCancelled(true); String text=e.getMessage();
        Bukkit.getScheduler().runTask(this,()->processInput(e.getPlayer(),input,text));
    }
    private void processInput(Player p,PendingInput in,String text) {
        if(text.equalsIgnoreCase("cancel")){p.sendMessage(color("&cAction cancelled."));return;}
        if(in.action.equals("add_section")) {
            String name=text.trim();
            if(name.isEmpty()||name.length()>32||getConfig().contains("sections."+name)){p.sendMessage(color("&cInvalid or existing section name."));return;}
            getConfig().set("sections."+name+".icon","CHEST");getConfig().set("sections."+name+".items",new LinkedHashMap<>());saveConfig();
            p.sendMessage(color("&aAdded section &f"+name));openAdmin(p);return;
        }
        String[] parts=text.trim().split("\\s+");
        if(parts.length!=2){p.sendMessage(color("&cEnter exactly two numbers, e.g. 100 35. Try /hrshop edit again."));return;}
        try {
            double buy=Double.parseDouble(parts[0]), sell=Double.parseDouble(parts[1]);
            if(!Double.isFinite(buy)||!Double.isFinite(sell)||buy<0||sell<0){throw new NumberFormatException();}
            String path="sections."+in.section+".items."+in.material.name();
            getConfig().set(path+".buy",buy);getConfig().set(path+".sell",sell);saveConfig();
            p.sendMessage(color("&aSaved "+in.material.name()+" prices. Buy: "+money(buy)+" Sell: "+money(sell)));
        } catch(NumberFormatException ex){p.sendMessage(color("&cInvalid prices. Use numbers such as 100 35."));}
        openAdmin(p);
    }
    private static final class ShopHolder implements InventoryHolder {
        private final Menu type; private final String section;
        private ShopHolder(Menu type,String section){this.type=type;this.section=section;}
        @Override public Inventory getInventory(){return null;}
    }
}
